import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection

configuracion_bp = Blueprint("configuracion_bp", __name__, url_prefix="/configuracion")


# ─────────────────────────────────────────────
# Helpers para leer/guardar configuración
# ─────────────────────────────────────────────

def cargar_configuracion():
    """
    Devuelve un diccionario {clave: valor} con toda la configuración.
    """
    conn = get_db_connection()
    cur = conn.cursor()

    # Aseguramos que exista la tabla (por si acaso)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS configuracion (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            clave TEXT UNIQUE NOT NULL,
            valor TEXT
        );
    """)

    cur.execute("SELECT clave, valor FROM configuracion")
    filas = cur.fetchall()
    conn.close()

    data = {}
    for fila in filas:
        data[fila["clave"]] = fila["valor"]

    return data


def guardar_configuracion(datos):
    """
    Recibe un dict {clave: valor} y guarda (upsert) en la tabla configuracion.
    """
    conn = get_db_connection()
    cur = conn.cursor()

    for clave, valor in datos.items():
        cur.execute("""
            INSERT INTO configuracion (clave, valor)
            VALUES (?, ?)
            ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor
        """, (clave, valor))

    conn.commit()
    conn.close()


# ─────────────────────────────────────────────
# VISTA PRINCIPAL DE CONFIGURACIÓN
# ─────────────────────────────────────────────

@configuracion_bp.route("/", methods=["GET", "POST"])
def lista():
    """
    Muestra y guarda la configuración general del sistema.
    """
    config_actual = cargar_configuracion()

    # Valores por defecto (si aún no están en BD)
    defaults = {
        "nombre_empresa": "ROI Aberturas",
        "razon_social": "",
        "cuit": "",
        "direccion": "",
        "telefono": "",
        "email": "",
        "sitio_web": "",
        "logo_archivo": "logo.png",
        "color_primario": "#0d6efd",

        "iva_default": "21",
        "moneda": "ARS",
        "numeracion_presupuestos": "1",
        "numeracion_facturas": "1",
        "numeracion_orden_trabajo": "1",
        "numeracion_remitos": "1",

        "auto_login": "1",  # 1 = sí, 0 = no
        "tiempo_sesion": "60",  # minutos
        "permitir_descarga_pdf": "1",

        "backups_automaticos": "0",
        "frecuencia_backup": "diario",  # diario / semanal / mensual
        "ruta_backup": "",
    }

    # Mezclamos lo que ya hay en BD con los defaults
    cfg = {}
    for k, v in defaults.items():
        cfg[k] = config_actual.get(k, v)

    if request.method == "POST":
        # Empresa
        cfg["nombre_empresa"] = request.form.get("nombre_empresa", "").strip()
        cfg["razon_social"] = request.form.get("razon_social", "").strip()
        cfg["cuit"] = request.form.get("cuit", "").strip()
        cfg["direccion"] = request.form.get("direccion", "").strip()
        cfg["telefono"] = request.form.get("telefono", "").strip()
        cfg["email"] = request.form.get("email", "").strip()
        cfg["sitio_web"] = request.form.get("sitio_web", "").strip()
        cfg["logo_archivo"] = request.form.get("logo_archivo", "").strip() or "logo.png"
        cfg["color_primario"] = request.form.get("color_primario", "#0d6efd")

        # Documentos / numeración / impuestos
        cfg["iva_default"] = request.form.get("iva_default", "21")
        cfg["moneda"] = request.form.get("moneda", "ARS")
        cfg["numeracion_presupuestos"] = request.form.get("numeracion_presupuestos", "1")
        cfg["numeracion_facturas"] = request.form.get("numeracion_facturas", "1")
        cfg["numeracion_orden_trabajo"] = request.form.get("numeracion_orden_trabajo", "1")
        cfg["numeracion_remitos"] = request.form.get("numeracion_remitos", "1")

        # Sistema / seguridad
        cfg["auto_login"] = request.form.get("auto_login", "0")
        cfg["tiempo_sesion"] = request.form.get("tiempo_sesion", "60")
        cfg["permitir_descarga_pdf"] = request.form.get("permitir_descarga_pdf", "0")

        # Backups
        cfg["backups_automaticos"] = request.form.get("backups_automaticos", "0")
        cfg["frecuencia_backup"] = request.form.get("frecuencia_backup", "diario")
        cfg["ruta_backup"] = request.form.get("ruta_backup", "").strip()

        guardar_configuracion(cfg)
        flash("Configuración guardada correctamente", "success")
        return redirect(url_for("configuracion_bp.lista"))

    # GET → mostramos el formulario con cfg
    return render_template("configuracion.html", cfg=cfg)
