from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection
from datetime import datetime

ctacte_proveedores_bp = Blueprint(
    "ctacte_proveedores_bp",
    __name__,
    url_prefix="/ctacte_proveedores"
)

# LISTADO GENERAL
@ctacte_proveedores_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT proveedor,
               SUM(debe) AS total_debe,
               SUM(haber) AS total_haber,
               SUM(debe - haber) AS saldo
        FROM ctacte_proveedores
        GROUP BY proveedor
        ORDER BY proveedor
    """)
    resumen = cur.fetchall()

    conn.close()
    return render_template("ctacte_proveedores_lista.html", resumen=resumen)

# NUEVO MOVIMIENTO
@ctacte_proveedores_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        fecha = request.form.get("fecha") or datetime.now().strftime("%Y-%m-%d")
        proveedor = request.form.get("proveedor", "").strip()
        concepto = request.form.get("concepto", "").strip()
        tipo = request.form.get("tipo", "debe")
        importe = request.form.get("importe", "0").replace(",", ".")

        try:
            importe = float(importe)
        except:
            importe = 0

        debe = importe if tipo == "debe" else 0
        haber = importe if tipo == "haber" else 0

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO ctacte_proveedores (fecha, proveedor, concepto, debe, haber)
            VALUES (?,?,?,?,?)
        """, (fecha, proveedor, concepto, debe, haber))
        conn.commit()
        conn.close()

        flash("Movimiento registrado correctamente", "success")
        return redirect(url_for("ctacte_proveedores_bp.lista"))

    return render_template("ctacte_proveedores_form.html", mov=None)

# DETALLE POR PROVEEDOR
@ctacte_proveedores_bp.route("/detalle/<proveedor>")
def detalle(proveedor):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT * FROM ctacte_proveedores
        WHERE proveedor=?
        ORDER BY fecha DESC, id DESC
    """, (proveedor,))
    movimientos = cur.fetchall()

    cur.execute("""
        SELECT SUM(debe - haber)
        FROM ctacte_proveedores
        WHERE proveedor=?
    """, (proveedor,))
    saldo = cur.fetchone()[0] or 0

    conn.close()
    return render_template("ctacte_proveedores_detalle.html",
                           proveedor=proveedor,
                           movimientos=movimientos,
                           saldo=saldo)

# ELIMINAR MOVIMIENTO
@ctacte_proveedores_bp.route("/eliminar/<int:mov_id>")
def eliminar(mov_id):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("DELETE FROM ctacte_proveedores WHERE id=?", (mov_id,))
    conn.commit()
    conn.close()
    flash("Movimiento eliminado", "info")
    return redirect(request.referrer or url_for("ctacte_proveedores_bp.lista"))
