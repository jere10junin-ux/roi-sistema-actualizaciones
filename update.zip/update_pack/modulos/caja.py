from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from config import get_db_connection
from datetime import datetime
import io
import csv

caja_bp = Blueprint("caja_bp", __name__, url_prefix="/caja")


# 🔹 LISTA PRINCIPAL
@caja_bp.route("/")
def lista():
    fecha = request.args.get("fecha") or datetime.today().strftime("%Y-%m-%d")

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT * FROM caja
        WHERE fecha = ?
        ORDER BY id DESC
        """,
        (fecha,),
    )
    movimientos = cur.fetchall()

    # Calcular totales
    ingresos = sum(m["importe"] for m in movimientos if m["tipo"] == "ingreso")
    egresos = sum(m["importe"] for m in movimientos if m["tipo"] == "egreso")
    balance = ingresos - egresos

    conn.close()

    return render_template(
        "caja_lista.html",
        movimientos=movimientos,
        fecha=fecha,
        ingresos=ingresos,
        egresos=egresos,
        balance=balance,
    )


# 🔹 NUEVO MOVIMIENTO
@caja_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        fecha = request.form.get("fecha") or datetime.today().strftime("%Y-%m-%d")
        tipo = request.form.get("tipo")
        detalle = request.form.get("detalle", "").strip()
        importe = request.form.get("importe", "0").replace(",", ".")
        metodo = request.form.get("metodo", "")
        categoria = request.form.get("categoria", "")

        try:
            importe = float(importe)
        except ValueError:
            importe = 0

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO caja (fecha, tipo, detalle, importe, metodo, categoria)
            VALUES (?,?,?,?,?,?)
            """,
            (fecha, tipo, detalle, importe, metodo, categoria),
        )
        conn.commit()
        conn.close()

        flash("Movimiento registrado correctamente", "success")
        return redirect(url_for("caja_bp.lista"))

    return render_template("caja_form.html", mov=None)


# 🔹 EDITAR
@caja_bp.route("/editar/<int:mov_id>", methods=["GET", "POST"])
def editar(mov_id):
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        fecha = request.form.get("fecha")
        tipo = request.form.get("tipo")
        detalle = request.form.get("detalle", "")
        importe = request.form.get("importe", "0").replace(",", ".")
        metodo = request.form.get("metodo", "")
        categoria = request.form.get("categoria", "")

        try:
            importe = float(importe)
        except ValueError:
            importe = 0

        cur.execute(
            """
            UPDATE caja SET fecha=?, tipo=?, detalle=?, importe=?, metodo=?, categoria=?
            WHERE id=?
            """,
            (fecha, tipo, detalle, importe, metodo, categoria, mov_id),
        )
        conn.commit()
        conn.close()

        flash("Movimiento actualizado", "success")
        return redirect(url_for("caja_bp.lista"))

    cur.execute("SELECT * FROM caja WHERE id=?", (mov_id,))
    mov = cur.fetchone()
    conn.close()

    return render_template("caja_form.html", mov=mov)


# 🔹 ELIMINAR
@caja_bp.route("/eliminar/<int:mov_id>")
def eliminar(mov_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM caja WHERE id=?", (mov_id,))
    conn.commit()
    conn.close()

    flash("Movimiento eliminado", "info")
    return redirect(url_for("caja_bp.lista"))


# 🔹 EXPORTAR A EXCEL (CSV)
@caja_bp.route("/exportar")
def exportar():
    fecha = request.args.get("fecha") or datetime.today().strftime("%Y-%m-%d")

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM caja WHERE fecha=?", (fecha,))
    movimientos = cur.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Fecha", "Tipo", "Detalle", "Importe", "Método", "Categoría"])

    for m in movimientos:
        writer.writerow([
            m["fecha"],
            m["tipo"],
            m["detalle"],
            m["importe"],
            m["metodo"],
            m["categoria"],
        ])

    output.seek(0)

    return send_file(
        io.BytesIO(output.getvalue().encode("utf-8")),
        as_attachment=True,
        download_name=f"caja_{fecha}.csv",
        mimetype="text/csv",
    )
