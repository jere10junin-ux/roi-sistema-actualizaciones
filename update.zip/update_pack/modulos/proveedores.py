
from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection

proveedores_bp = Blueprint("proveedores_bp", __name__, url_prefix="/proveedores")


@proveedores_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM proveedores ORDER BY nombre")
    proveedores = cur.fetchall()
    conn.close()
    return render_template("proveedores_lista.html", proveedores=proveedores)


@proveedores_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        telefono = request.form.get("telefono", "").strip()
        direccion = request.form.get("direccion", "").strip()
        email = request.form.get("email", "").strip()

        if not nombre:
            flash("El nombre es obligatorio", "danger")
            return redirect(url_for("proveedores_bp.nuevo"))

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO proveedores (nombre, telefono, direccion, email) VALUES (?,?,?,?)",
            (nombre, telefono, direccion, email),
        )
        conn.commit()
        conn.close()
        flash("Proveedor creado correctamente", "success")
        return redirect(url_for("proveedores_bp.lista"))

    return render_template("proveedores_form.html", proveedor=None)


@proveedores_bp.route("/editar/<int:proveedor_id>", methods=["GET", "POST"])
def editar(proveedor_id):
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        telefono = request.form.get("telefono", "").strip()
        direccion = request.form.get("direccion", "").strip()
        email = request.form.get("email", "").strip()

        cur.execute(
            "UPDATE proveedores SET nombre=?, telefono=?, direccion=?, email=? WHERE id=?",
            (nombre, telefono, direccion, email, proveedor_id),
        )
        conn.commit()
        conn.close()
        flash("Proveedor modificado", "success")
        return redirect(url_for("proveedores_bp.lista"))

    cur.execute("SELECT * FROM proveedores WHERE id=?", (proveedor_id,))
    proveedor = cur.fetchone()
    conn.close()
    return render_template("proveedores_form.html", proveedor=proveedor)


@proveedores_bp.route("/eliminar/<int:proveedor_id>")
def eliminar(proveedor_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM proveedores WHERE id=?", (proveedor_id,))
    conn.commit()
    conn.close()
    flash("Proveedor eliminado", "info")
    return redirect(url_for("proveedores_bp.lista"))
