
from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection
from datetime import datetime

compras_bp = Blueprint("compras_bp", __name__, url_prefix="/compras")


@compras_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM compras ORDER BY fecha DESC, id DESC")
    compras = cur.fetchall()
    conn.close()
    return render_template("compras_lista.html", compras=compras)


@compras_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        fecha = request.form.get("fecha") or datetime.today().strftime("%Y-%m-%d")
        proveedor = request.form.get("proveedor", "").strip()
        producto = request.form.get("producto", "").strip()
        cantidad = request.form.get("cantidad", "1").replace(",", ".")
        precio_unitario = request.form.get("precio_unitario", "0").replace(",", ".")
        forma_pago = request.form.get("forma_pago", "").strip()
        observaciones = request.form.get("observaciones", "").strip()

        try:
            cantidad = float(cantidad)
        except ValueError:
            cantidad = 1
        try:
            precio_unitario = float(precio_unitario)
        except ValueError:
            precio_unitario = 0

        total = cantidad * precio_unitario

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO compras (fecha, proveedor, producto, cantidad, precio_unitario, total, forma_pago, observaciones)
            VALUES (?,?,?,?,?,?,?,?)
            """,
            (fecha, proveedor, producto, cantidad, precio_unitario, total, forma_pago, observaciones),
        )
        conn.commit()
        conn.close()
        flash("Compra registrada", "success")
        return redirect(url_for("compras_bp.lista"))

    return render_template("compras_form.html", compra=None)
