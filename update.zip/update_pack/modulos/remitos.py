
from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection
from datetime import datetime

remitos_bp = Blueprint("remitos_bp", __name__, url_prefix="/remitos")


@remitos_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM remitos ORDER BY fecha DESC, id DESC")
    remitos = cur.fetchall()
    conn.close()
    return render_template("remitos_lista.html", remitos=remitos)


@remitos_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        fecha = request.form.get("fecha") or datetime.today().strftime("%Y-%m-%d")
        cliente = request.form.get("cliente", "").strip()
        total = request.form.get("total", "0").replace(",", ".")
        observaciones = request.form.get("observaciones", "").strip()

        try:
            total = float(total)
        except ValueError:
            total = 0

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO remitos (fecha, cliente, total, observaciones) VALUES (?,?,?,?)",
            (fecha, cliente, total, observaciones),
        )
        conn.commit()
        conn.close()
        flash("Remito generado", "success")
        return redirect(url_for("remitos_bp.lista"))

    return render_template("remitos_nuevo.html")
