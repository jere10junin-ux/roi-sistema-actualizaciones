import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection
from datetime import datetime

presupuestos_bp = Blueprint("presupuestos_bp", __name__, url_prefix="/presupuestos")

# ─────────────────────────────────────────────
# LISTADO DE PRESUPUESTOS (con búsqueda)
# ─────────────────────────────────────────────
@presupuestos_bp.route("/", methods=["GET"])
def lista():
    buscar = request.args.get("buscar", "").strip()

    conn = get_db_connection()
    cur = conn.cursor()

    if buscar:
        cur.execute("""
            SELECT * FROM presupuestos
            WHERE cliente LIKE ?
            OR estado LIKE ?
            ORDER BY fecha DESC
        """, (f"%{buscar}%", f"%{buscar}%"))
    else:
        cur.execute("SELECT * FROM presupuestos ORDER BY fecha DESC")

    presupuestos = cur.fetchall()
    conn.close()

    return render_template("presupuestos_lista.html",
                           presupuestos=presupuestos,
                           buscar=buscar)


# ─────────────────────────────────────────────
# CREAR PRESUPUESTO
# ─────────────────────────────────────────────
@presupuestos_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":

        fecha = request.form.get("fecha") or datetime.today().strftime("%Y-%m-%d")
        cliente = request.form.get("cliente", "").strip()
        total = request.form.get("total", "0").replace(",", ".")
        estado = request.form.get("estado", "pendiente")

        if cliente == "":
            flash("El cliente no puede estar vacío", "danger")
            return redirect(url_for("presupuestos_bp.nuevo"))

        try:
            total = float(total)
        except ValueError:
            total = 0

        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO presupuestos (fecha, cliente, total, estado)
            VALUES (?,?,?,?)
        """, (fecha, cliente, total, estado))

        conn.commit()
        conn.close()

        flash("Presupuesto creado correctamente", "success")
        return redirect(url_for("presupuestos_bp.lista"))

    # GET
    return render_template("presupuestos_form.html", presupuesto=None)


# ─────────────────────────────────────────────
# EDITAR PRESUPUESTO
# ─────────────────────────────────────────────
@presupuestos_bp.route("/editar/<int:presupuesto_id>", methods=["GET", "POST"])
def editar(presupuesto_id):

    conn = get_db_connection()
    cur = conn.cursor()

    # POST → guardar cambios
    if request.method == "POST":
        fecha = request.form.get("fecha")
        cliente = request.form.get("cliente", "").strip()
        total = request.form.get("total", "0").replace(",", ".")
        estado = request.form.get("estado", "pendiente")

        try:
            total = float(total)
        except ValueError:
            total = 0

        cur.execute("""
            UPDATE presupuestos
            SET fecha=?, cliente=?, total=?, estado=?
            WHERE id=?
        """, (fecha, cliente, total, estado, presupuesto_id))

        conn.commit()
        conn.close()

        flash("Presupuesto modificado correctamente", "success")
        return redirect(url_for("presupuestos_bp.lista"))

    # GET → mostrar datos actuales
    cur.execute("SELECT * FROM presupuestos WHERE id=?", (presupuesto_id,))
    presupuesto = cur.fetchone()
    conn.close()

    if presupuesto is None:
        flash("Presupuesto no encontrado", "danger")
        return redirect(url_for("presupuestos_bp.lista"))

    return render_template("presupuestos_form.html", presupuesto=presupuesto)


# ─────────────────────────────────────────────
# VER PRESUPUESTO (detalle)
# ─────────────────────────────────────────────
@presupuestos_bp.route("/ver/<int:presupuesto_id>")
def ver(presupuesto_id):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT * FROM presupuestos WHERE id=?", (presupuesto_id,))
    presupuesto = cur.fetchone()

    conn.close()

    if not presupuesto:
        flash("Presupuesto no encontrado", "danger")
        return redirect(url_for("presupuestos_bp.lista"))

    return render_template("presupuestos_ver.html", presupuesto=presupuesto)


# ─────────────────────────────────────────────
# DUPLICAR PRESUPUESTO
# ─────────────────────────────────────────────
@presupuestos_bp.route("/duplicar/<int:presupuesto_id>")
def duplicar(presupuesto_id):

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT * FROM presupuestos WHERE id=?", (presupuesto_id,))
    p = cur.fetchone()

    if not p:
        flash("Presupuesto no encontrado", "danger")
        return redirect(url_for("presupuestos_bp.lista"))

    nueva_fecha = datetime.today().strftime("%Y-%m-%d")

    cur.execute("""
        INSERT INTO presupuestos (fecha, cliente, total, estado)
        VALUES (?, ?, ?, ?)
    """, (nueva_fecha, p["cliente"], p["total"], "pendiente"))

    conn.commit()
    conn.close()

    flash("Presupuesto duplicado correctamente", "success")
    return redirect(url_for("presupuestos_bp.lista"))


# ─────────────────────────────────────────────
# CAMBIAR ESTADO
# ─────────────────────────────────────────────
@presupuestos_bp.route("/estado/<int:presupuesto_id>/<string:nuevo_estado>")
def cambiar_estado(presupuesto_id, nuevo_estado):

    estados_validos = ["pendiente", "enviado", "aceptado", "rechazado"]

    if nuevo_estado not in estados_validos:
        flash("Estado inválido", "danger")
        return redirect(url_for("presupuestos_bp.lista"))

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE presupuestos SET estado=? WHERE id=?",
                (nuevo_estado, presupuesto_id))
    conn.commit()
    conn.close()

    flash(f"Estado cambiado a '{nuevo_estado}'", "success")
    return redirect(url_for("presupuestos_bp.lista"))


# ─────────────────────────────────────────────
# ELIMINAR PRESUPUESTO
# ─────────────────────────────────────────────
@presupuestos_bp.route("/eliminar/<int:presupuesto_id>")
def eliminar(presupuesto_id):

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("DELETE FROM presupuestos WHERE id=?", (presupuesto_id,))
    conn.commit()
    conn.close()

    flash("Presupuesto eliminado correctamente", "info")
    return redirect(url_for("presupuestos_bp.lista"))
