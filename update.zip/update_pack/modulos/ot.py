from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection
from datetime import datetime

ot_bp = Blueprint("ot_bp", __name__, url_prefix="/ot")


# 📌 LISTA
@ot_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM ot ORDER BY fecha DESC, id DESC")
    ots = cur.fetchall()
    conn.close()
    return render_template("ot_lista.html", ots=ots)


# 📌 NUEVA OT
@ot_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        fecha = request.form.get("fecha") or datetime.today().strftime("%Y-%m-%d")
        cliente = request.form.get("cliente", "").strip()
        descripcion = request.form.get("descripcion", "").strip()
        estado = request.form.get("estado", "en_proceso")

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO ot (fecha, cliente, descripcion, estado) VALUES (?,?,?,?)",
            (fecha, cliente, descripcion, estado),
        )
        conn.commit()
        conn.close()

        flash("Orden de trabajo creada correctamente.", "success")
        return redirect(url_for("ot_bp.lista"))

    return render_template("ot_form.html", ot=None)


# 📌 EDITAR OT
@ot_bp.route("/editar/<int:ot_id>", methods=["GET", "POST"])
def editar(ot_id):
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        fecha = request.form.get("fecha")
        cliente = request.form.get("cliente")
        descripcion = request.form.get("descripcion")
        estado = request.form.get("estado")

        cur.execute("""
            UPDATE ot SET fecha=?, cliente=?, descripcion=?, estado=?
            WHERE id=?
        """, (fecha, cliente, descripcion, estado, ot_id))

        conn.commit()
        conn.close()
        flash("Orden de trabajo actualizada.", "success")
        return redirect(url_for("ot_bp.lista"))

    cur.execute("SELECT * FROM ot WHERE id=?", (ot_id,))
    ot = cur.fetchone()
    conn.close()

    return render_template("ot_form.html", ot=ot)


# 📌 VER OT (detalle)
@ot_bp.route("/ver/<int:ot_id>")
def ver(ot_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM ot WHERE id=?", (ot_id,))
    ot = cur.fetchone()
    conn.close()

    if not ot:
        flash("OT no encontrada.", "danger")
        return redirect(url_for("ot_bp.lista"))

    return render_template("ot_ver.html", ot=ot)


# 📌 CAMBIAR ESTADO
@ot_bp.route("/estado/<int:ot_id>/<string:nuevo>")
def cambiar_estado(ot_id, nuevo):
    estados_validos = ["pendiente", "en_proceso", "pausada", "finalizada", "cancelada"]

    if nuevo not in estados_validos:
        flash("Estado inválido.", "warning")
        return redirect(url_for("ot_bp.lista"))

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("UPDATE ot SET estado=? WHERE id=?", (nuevo, ot_id))
    conn.commit()
    conn.close()

    flash("Estado actualizado.", "info")
    return redirect(url_for("ot_bp.ver", ot_id=ot_id))


# 📌 ELIMINAR
@ot_bp.route("/eliminar/<int:ot_id>")
def eliminar(ot_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM ot WHERE id=?", (ot_id,))
    conn.commit()
    conn.close()

    flash("Orden de trabajo eliminada.", "warning")
    return redirect(url_for("ot_bp.lista"))
