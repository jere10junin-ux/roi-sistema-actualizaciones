from flask import Blueprint, render_template, redirect, url_for, flash
from utils.version_manager import (
    get_local_version,
    get_remote_version,
    is_newer,
    download_update,
    apply_update
)

actualizador_bp = Blueprint("actualizador_bp", __name__, url_prefix="/actualizador")


@actualizador_bp.route("/")
def inicio():
    local_v = get_local_version()
    remote_v = get_remote_version()

    nueva = remote_v and is_newer(remote_v, local_v)

    return render_template(
        "actualizador.html",
        local_v=local_v,
        remote_v=remote_v,
        nueva=nueva
    )


@actualizador_bp.route("/actualizar")
def actualizar():
    if not download_update():
        flash("Error descargando actualización.", "danger")
        return redirect(url_for("actualizador_bp.inicio"))

    if not apply_update():
        flash("Error aplicando actualización.", "danger")
        return redirect(url_for("actualizador_bp.inicio"))

    flash("Actualización completada con éxito.", "success")
    return redirect(url_for("actualizador_bp.inicio"))
