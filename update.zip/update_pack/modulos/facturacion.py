from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from config import get_db_connection
from datetime import datetime
import io
import os

try:
    # Opcional: para generar PDF de la factura
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
except Exception:  # si no está instalado reportlab, el resto del módulo sigue funcionando
    A4 = None
    canvas = None

facturacion_bp = Blueprint("facturacion_bp", __name__, url_prefix="/facturacion")


# ─────────────────────────────────────────────
# Helpers de configuración
# ─────────────────────────────────────────────

def _obtener_configuracion(clave, defecto=""):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT valor FROM configuracion WHERE clave=?", (clave,))
    row = cur.fetchone()
    conn.close()
    return row["valor"] if row and row["valor"] not in (None, "") else defecto


def _guardar_configuracion(clave, valor):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT OR REPLACE INTO configuracion (clave, valor) VALUES (?, ?)",
        (clave, str(valor)),
    )
    conn.commit()
    conn.close()


def _obtener_config_empresa():
    """
    Devuelve un dict con datos de empresa para usar en PDFs y encabezados.
    Usa la tabla configuracion (módulo Configuración PRO que ya hicimos).
    """
    cfg = {
        "nombre_empresa": _obtener_configuracion("nombre_empresa", "ROI Aberturas"),
        "razon_social": _obtener_configuracion("razon_social", ""),
        "cuit": _obtener_configuracion("cuit", ""),
        "direccion": _obtener_configuracion("direccion", ""),
        "telefono": _obtener_configuracion("telefono", ""),
        "email": _obtener_configuracion("email", ""),
        "sitio_web": _obtener_configuracion("sitio_web", ""),
        "logo_archivo": _obtener_configuracion("logo_archivo", "logo.png"),
        "color_primario": _obtener_configuracion("color_primario", "#123456"),
        "iva_default": _obtener_configuracion("iva_default", "21"),
    }
    return cfg


def _hex_to_rgb(color_hex, default=(0.07, 0.20, 0.40)):
    """
    Convierte un color #RRGGBB a tupla (r,g,b) 0–1 para reportlab.
    """
    if not color_hex:
        return default
    color_hex = color_hex.lstrip("#")
    if len(color_hex) != 6:
        return default
    try:
        r = int(color_hex[0:2], 16) / 255.0
        g = int(color_hex[2:4], 16) / 255.0
        b = int(color_hex[4:6], 16) / 255.0
        return (r, g, b)
    except ValueError:
        return default


def _generar_numero_factura(letra, punto_venta):
    """
    Genera un número de factura estilo AFIP:
    LETRA-PTO-00000001

    Usa configuracion.numeracion_facturas como correlativo principal.
    Si no existe, cae en factura_ultimo_numero (compatibilidad con tu versión anterior).
    """
    # Intentar con nueva clave
    numero_str = _obtener_configuracion("numeracion_facturas", "")
    if not numero_str:
        # Compatibilidad con la versión anterior
        numero_str = _obtener_configuracion("factura_ultimo_numero", "0")

    try:
        ultimo_int = int(numero_str)
    except ValueError:
        ultimo_int = 0

    nuevo = ultimo_int + 1

    # Guardamos en ambas claves para mantener todo alineado
    _guardar_configuracion("numeracion_facturas", nuevo)
    _guardar_configuracion("factura_ultimo_numero", nuevo)

    pto = (punto_venta or "0001").zfill(4)
    letra = letra or "C"
    return f"{letra}-{pto}-{nuevo:08d}"


# ─────────────────────────────────────────────
# LISTADO DE FACTURAS
# ─────────────────────────────────────────────

@facturacion_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT f.*, c.nombre AS cliente_nombre_real
        FROM facturas f
        LEFT JOIN clientes c ON f.cliente_id = c.id
        ORDER BY fecha DESC, id DESC
        """
    )
    facturas = cur.fetchall()
    conn.close()
    return render_template("facturas_lista.html", facturas=facturas)


# ─────────────────────────────────────────────
# NUEVA FACTURA
# ─────────────────────────────────────────────

@facturacion_bp.route("/nueva", methods=["GET", "POST"])
def nueva():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, nombre FROM clientes ORDER BY nombre")
    clientes = cur.fetchall()
    conn.close()

    if request.method == "POST":
        fecha = request.form.get("fecha") or datetime.now().strftime("%Y-%m-%d")
        cliente_id = request.form.get("cliente_id") or None
        tipo = request.form.get("tipo") or "C"
        letra = request.form.get("letra") or _obtener_configuracion(
            "factura_letra_default", "C"
        )
        punto_venta = request.form.get("punto_venta") or _obtener_configuracion(
            "factura_punto_venta", "0001"
        )

        descripciones = request.form.getlist("item_descripcion")
        cantidades = request.form.getlist("item_cantidad")
        precios = request.form.getlist("item_precio")

        items = []
        total = 0.0
        for desc, cant, prec in zip(descripciones, cantidades, precios):
            desc = (desc or "").strip()
            if not desc:
                continue
            try:
                cant_f = float(cant or 0)
            except ValueError:
                cant_f = 0
            try:
                prec_f = float(prec or 0)
            except ValueError:
                prec_f = 0
            subtotal = cant_f * prec_f
            total += subtotal
            items.append((desc, cant_f, prec_f, subtotal))

        if not items:
            flash("Debe ingresar al menos un ítem.", "warning")
            return redirect(url_for("facturacion_bp.nueva"))

        # Generar número de factura
        numero = _generar_numero_factura(letra, punto_venta)

        conn = get_db_connection()
        cur = conn.cursor()

        # Obtener nombre de cliente si hay ID
        cliente_nombre = None
        if cliente_id:
            cur.execute("SELECT nombre FROM clientes WHERE id=?", (cliente_id,))
            row = cur.fetchone()
            if row:
                cliente_nombre = row["nombre"]

        cur.execute(
            """
            INSERT INTO facturas (numero, fecha, cliente_id, cliente_nombre, tipo, letra, punto_venta, total, estado)
            VALUES (?,?,?,?,?,?,?,?,?)
            """,
            (
                numero,
                fecha,
                cliente_id,
                cliente_nombre,
                tipo,
                letra,
                punto_venta,
                total,
                "EMITIDA",
            ),
        )
        factura_id = cur.lastrowid

        for desc, cant_f, prec_f, subtotal in items:
            cur.execute(
                """
                INSERT INTO facturas_detalle (factura_id, producto, cantidad, precio, subtotal)
                VALUES (?,?,?,?,?)
                """,
                (factura_id, desc, cant_f, prec_f, subtotal),
            )

        conn.commit()
        conn.close()

        # Guardar por defecto la letra y punto de venta usados
        _guardar_configuracion("factura_letra_default", letra)
        _guardar_configuracion("factura_punto_venta", punto_venta)

        flash(f"Factura {numero} creada correctamente.", "success")
        return redirect(url_for("facturacion_bp.lista"))

    # Valores por defecto para el formulario
    fecha_hoy = datetime.now().strftime("%Y-%m-%d")
    letra_default = _obtener_configuracion("factura_letra_default", "C")
    pto_default = _obtener_configuracion("factura_punto_venta", "0001")

    return render_template(
        "facturas_nueva.html",
        clientes=clientes,
        fecha_hoy=fecha_hoy,
        letra_default=letra_default,
        pto_default=pto_default,
    )


# ─────────────────────────────────────────────
# VER FACTURA
# ─────────────────────────────────────────────

@facturacion_bp.route("/ver/<int:factura_id>")
def ver(factura_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM facturas WHERE id=?", (factura_id,))
    factura = cur.fetchone()
    if not factura:
        conn.close()
        flash("Factura no encontrada.", "warning")
        return redirect(url_for("facturacion_bp.lista"))

    cur.execute(
        "SELECT * FROM facturas_detalle WHERE factura_id=?",
        (factura_id,),
    )
    items = cur.fetchall()
    conn.close()

    return render_template("facturas_ver.html", factura=factura, items=items)


# ─────────────────────────────────────────────
# ANULAR FACTURA
# ─────────────────────────────────────────────

@facturacion_bp.route("/anular/<int:factura_id>")
def anular(factura_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE facturas SET estado='ANULADA' WHERE id=?", (factura_id,))
    conn.commit()
    conn.close()
    flash("Factura anulada.", "info")
    return redirect(url_for("facturacion_bp.lista"))


# ─────────────────────────────────────────────
# GENERAR FACTURA DESDE VENTA
# ─────────────────────────────────────────────

@facturacion_bp.route("/desde_venta/<int:venta_id>")
def desde_venta(venta_id):
    """
    Crea una factura rápida a partir de una venta existente.
    Usa el cliente y el producto de la tabla ventas.
    """
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM ventas WHERE id=?", (venta_id,))
    venta = cur.fetchone()
    conn.close()

    if not venta:
        flash("Venta no encontrada.", "warning")
        return redirect(url_for("ventas_bp.lista"))

    # Prellenamos formulario de factura con datos de la venta
    fecha = venta["fecha"] or datetime.now().strftime("%Y-%m-%d")
    cliente_nombre = venta["cliente"]
    producto = venta["producto"]
    cantidad = venta["cantidad"] or 1
    precio_unitario = venta["precio_unitario"] or 0

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, nombre FROM clientes ORDER BY nombre")
    clientes = cur.fetchall()
    conn.close()

    fecha_hoy = fecha
    letra_default = _obtener_configuracion("factura_letra_default", "C")
    pto_default = _obtener_configuracion("factura_punto_venta", "0001")

    item_prefill = {
        "descripcion": producto,
        "cantidad": cantidad,
        "precio": precio_unitario,
    }

    return render_template(
        "facturas_nueva.html",
        clientes=clientes,
        fecha_hoy=fecha_hoy,
        letra_default=letra_default,
        pto_default=pto_default,
        cliente_nombre_prefill=cliente_nombre,
        item_prefill=item_prefill,
    )


# ─────────────────────────────────────────────
# PDF PROFESIONAL (Opción A)
# ─────────────────────────────────────────────

@facturacion_bp.route("/pdf/<int:factura_id>")
def pdf(factura_id):
    """
    Genera un PDF profesional con logo, encabezado, datos de empresa y detalle.
    """
    if canvas is None or A4 is None:
        flash(
            "Para generar el PDF es necesario instalar la librería 'reportlab'. "
            "Ejecutá: pip install reportlab",
            "warning",
        )
        return redirect(url_for("facturacion_bp.ver", factura_id=factura_id))

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM facturas WHERE id=?", (factura_id,))
    factura = cur.fetchone()
    if not factura:
        conn.close()
        flash("Factura no encontrada.", "warning")
        return redirect(url_for("facturacion_bp.lista"))

    cur.execute(
        "SELECT * FROM facturas_detalle WHERE factura_id=?",
        (factura_id,),
    )
    items = cur.fetchall()
    conn.close()

    # Config empresa
    cfg = _obtener_config_empresa()

    # Cálculo neto / IVA / total
    total = float(factura["total"] or 0)
    suma_items = sum(float(i["subtotal"] or 0) for i in items)
    try:
        iva_porcentaje = float(cfg["iva_default"] or 0)
    except ValueError:
        iva_porcentaje = 0.0

    if iva_porcentaje > 0:
        neto = suma_items / (1 + iva_porcentaje / 100) if suma_items else total / (
            1 + iva_porcentaje / 100
        )
        iva_monto = total - neto
    else:
        neto = total
        iva_monto = 0.0

    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    margin_x = 40
    y = height - 50

    # Encabezado con color corporativo
    r, g, b = _hex_to_rgb(cfg["color_primario"])
    c.setFillColorRGB(r, g, b)
    c.rect(0, height - 80, width, 80, stroke=0, fill=1)

    # Logo (si existe)
    logo_path = os.path.join(os.path.abspath("."), "static", cfg["logo_archivo"])
    if os.path.exists(logo_path):
        try:
            c.drawImage(logo_path, margin_x, height - 75, width=80, preserveAspectRatio=True, mask="auto")
        except Exception:
            pass

    # Nombre empresa en blanco
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 16)
    c.drawString(margin_x + 90, height - 40, cfg["nombre_empresa"])

    c.setFont("Helvetica", 9)
    detalle_emp = []
    if cfg["razon_social"]:
        detalle_emp.append(cfg["razon_social"])
    if cfg["cuit"]:
        detalle_emp.append(f"CUIT: {cfg['cuit']}")
    if cfg["direccion"]:
        detalle_emp.append(cfg["direccion"])
    if cfg["telefono"]:
        detalle_emp.append(f"Tel: {cfg['telefono']}")
    if cfg["email"]:
        detalle_emp.append(cfg["email"])
    if cfg["sitio_web"]:
        detalle_emp.append(cfg["sitio_web"])

    yy = height - 55
    for linea in detalle_emp:
        c.drawString(margin_x + 90, yy, linea)
        yy -= 12

    # Cuadro tipo / número / fecha a la derecha
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 18)
    c.drawRightString(width - margin_x, height - 35, f"FACTURA {factura['letra']}")

    c.setFont("Helvetica", 10)
    c.drawRightString(width - margin_x, height - 52, f"N° {factura['numero']}")
    c.drawRightString(width - margin_x, height - 66, f"Fecha: {factura['fecha'] or ''}")

    # Datos de cliente
    y = height - 110
    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica-Bold", 11)
    c.drawString(margin_x, y, "Cliente")
    y -= 5
    c.line(margin_x, y, width - margin_x, y)
    y -= 15

    c.setFont("Helvetica", 10)
    c.drawString(margin_x, y, f"Nombre: {factura['cliente_nombre'] or ''}")
    y -= 14
    # Si en el futuro agregás CUIT del cliente, se imprime acá
    # c.drawString(margin_x, y, f"CUIT: ...")
    y -= 10

    # Cabecera de detalle
    y -= 10
    c.setFont("Helvetica-Bold", 10)
    c.drawString(margin_x, y, "Detalle")
    c.drawRightString(margin_x + 320, y, "Cant.")
    c.drawRightString(margin_x + 420, y, "Precio")
    c.drawRightString(width - margin_x, y, "Subtotal")
    y -= 8
    c.line(margin_x, y, width - margin_x, y)
    y -= 15

    c.setFont("Helvetica", 10)
    for item in items:
        if y < 80:
            # Nueva página
            c.showPage()
            y = height - 80

            c.setFont("Helvetica-Bold", 10)
            c.drawString(margin_x, y, "Detalle")
            c.drawRightString(margin_x + 320, y, "Cant.")
            c.drawRightString(margin_x + 420, y, "Precio")
            c.drawRightString(width - margin_x, y, "Subtotal")
            y -= 8
            c.line(margin_x, y, width - margin_x, y)
            y -= 15
            c.setFont("Helvetica", 10)

        c.drawString(margin_x, y, str(item["producto"]))
        c.drawRightString(margin_x + 320, y, f"{item['cantidad']:.2f}")
        c.drawRightString(margin_x + 420, y, f"{item['precio']:.2f}")
        c.drawRightString(width - margin_x, y, f"{item['subtotal']:.2f}")
        y -= 18

    # Totales
    y -= 5
    c.line(margin_x, y, width - margin_x, y)
    y -= 18

    c.setFont("Helvetica", 10)
    c.drawRightString(width - margin_x - 120, y, "Neto:")
    c.drawRightString(width - margin_x, y, f"{neto:.2f}")
    y -= 14

    if iva_porcentaje > 0:
        c.drawRightString(width - margin_x - 120, y, f"IVA {iva_porcentaje:.0f}%:")
        c.drawRightString(width - margin_x, y, f"{iva_monto:.2f}")
        y -= 14

    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(width - margin_x - 120, y, "TOTAL:")
    c.drawRightString(width - margin_x, y, f"{total:.2f}")

    # Pie
    c.setFont("Helvetica", 8)
    c.setFillColorRGB(0.3, 0.3, 0.3)
    c.drawString(margin_x, 30, "Documento generado por ROI Sistema de Gestión")

    c.showPage()
    c.save()
    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name=f"factura_{factura['numero']}.pdf",
        mimetype="application/pdf",
    )
