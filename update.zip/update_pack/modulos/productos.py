from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from config import get_db_connection
from datetime import datetime
import io
import openpyxl

productos_bp = Blueprint("productos_bp", __name__, url_prefix="/productos")


# 📌 LISTA DE PRODUCTOS
@productos_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM productos ORDER BY nombre ASC")
    productos = cur.fetchall()
    conn.close()
    return render_template("productos_lista.html", productos=productos)


# 📌 NUEVO PRODUCTO
@productos_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        codigo = request.form.get("codigo", "").strip()
        nombre = request.form.get("nombre", "").strip()
        categoria = request.form.get("categoria", "").strip()
        unidad = request.form.get("unidad", "").strip()
        descripcion = request.form.get("descripcion", "").strip()

        precio = request.form.get("precio", "0").replace(",", ".")
        stock = request.form.get("stock", "0").replace(",", ".")

        if not nombre:
            flash("El nombre del producto es obligatorio.", "danger")
            return redirect(url_for("productos_bp.nuevo"))

        try:
            precio = float(precio)
        except:
            precio = 0

        try:
            stock = float(stock)
        except:
            stock = 0

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO productos (codigo, nombre, categoria, unidad, descripcion, precio, stock)
            VALUES (?,?,?,?,?,?,?)
        """, (codigo, nombre, categoria, unidad, descripcion, precio, stock))
        conn.commit()
        conn.close()

        flash("Producto guardado correctamente.", "success")
        return redirect(url_for("productos_bp.lista"))

    return render_template("productos_form.html", producto=None)


# 📌 EDITAR PRODUCTO
@productos_bp.route("/editar/<int:producto_id>", methods=["GET", "POST"])
def editar(producto_id):
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        codigo = request.form.get("codigo", "").strip()
        nombre = request.form.get("nombre", "").strip()
        categoria = request.form.get("categoria", "").strip()
        unidad = request.form.get("unidad", "").strip()
        descripcion = request.form.get("descripcion", "").strip()

        precio = request.form.get("precio", "0").replace(",", ".")
        stock = request.form.get("stock", "0").replace(",", ".")

        try:
            precio = float(precio)
        except:
            precio = 0

        try:
            stock = float(stock)
        except:
            stock = 0

        cur.execute("""
            UPDATE productos SET codigo=?, nombre=?, categoria=?, unidad=?,
            descripcion=?, precio=?, stock=? WHERE id=?
        """, (codigo, nombre, categoria, unidad, descripcion, precio, stock, producto_id))

        conn.commit()
        conn.close()

        flash("Producto actualizado.", "success")
        return redirect(url_for("productos_bp.lista"))

    cur.execute("SELECT * FROM productos WHERE id=?", (producto_id,))
    producto = cur.fetchone()
    conn.close()

    return render_template("productos_form.html", producto=producto)


# 📌 ELIMINAR PRODUCTO
@productos_bp.route("/eliminar/<int:producto_id>")
def eliminar(producto_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM productos WHERE id=?", (producto_id,))
    conn.commit()
    conn.close()

    flash("Producto eliminado.", "warning")
    return redirect(url_for("productos_bp.lista"))


# 📌 DESCARGAR PLANTILLA XLSX
@productos_bp.route("/descargar_plantilla")
def descargar_plantilla():

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Productos"

    ws.append(["codigo", "nombre", "categoria", "unidad", "descripcion", "precio", "stock"])

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="plantilla_productos.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


# 📌 IMPORTAR PRODUCTOS DESDE EXCEL
@productos_bp.route("/importar", methods=["GET", "POST"])
def importar():
    if request.method == "POST":
        file = request.files.get("archivo")

        if not file:
            flash("Debe seleccionar un archivo Excel (.xlsx)", "danger")
            return redirect(url_for("productos_bp.importar"))

        wb = openpyxl.load_workbook(file)
        ws = wb.active

        conn = get_db_connection()
        cur = conn.cursor()

        filas_ok = 0
        filas_error = 0

        for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            codigo, nombre, categoria, unidad, descripcion, precio, stock = row

            if not nombre:
                filas_error += 1
                continue

            try:
                precio = float(precio or 0)
            except:
                precio = 0
            
            try:
                stock = float(stock or 0)
            except:
                stock = 0

            try:
                cur.execute("""
                    INSERT INTO productos (codigo, nombre, categoria, unidad, descripcion, precio, stock)
                    VALUES (?,?,?,?,?,?,?)
                """, (codigo, nombre, categoria, unidad, descripcion, precio, stock))
                filas_ok += 1
            except:
                filas_error += 1

        conn.commit()
        conn.close()

        flash(f"Importación finalizada. {filas_ok} productos cargados, {filas_error} con error.", "info")
        return redirect(url_for("productos_bp.lista"))

    return render_template("productos_importar.html")
