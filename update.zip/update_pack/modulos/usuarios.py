import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from config import get_db_connection

usuarios_bp = Blueprint("usuarios_bp", __name__, url_prefix="/usuarios")


@usuarios_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":

        usuario = request.form.get("usuario", "").strip()
        password = request.form.get("password", "").strip()

        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("SELECT * FROM usuarios WHERE usuario=? AND password=?", (usuario, password))
        user = cur.fetchone()
        conn.close()

        if user:
            session["usuario_id"] = user["id"]
            session["usuario_nombre"] = user["usuario"]

            return redirect(url_for("dashboard"))
        else:
            flash("Usuario o contraseña incorrectos", "danger")

    return render_template("login.html")


@usuarios_bp.route("/logout")
def logout():
    session.clear()
    flash("Sesión finalizada correctamente", "info")
    return redirect(url_for("usuarios_bp.login"))
