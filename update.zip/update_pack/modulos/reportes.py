from flask import Blueprint, render_template, send_file
from config import get_db_connection
import io
import pandas as pd

reportes_bp = Blueprint("reportes_bp", __name__, url_prefix="/reportes")


@reportes_bp.route("/")
def lista():
    """
    Vista principal de reportes: totales, últimas ventas y ranking de productos.
    """
    conn = get_db_connection()
    cur = conn.cursor()

    # Totales ventas
    try:
        cur.execute("SELECT SUM(total) AS t FROM ventas")
        tv = cur.fetchone()["t"] or 0
    except Exception:
        tv = 0

    # Totales compras
    try:
        cur.execute("SELECT SUM(total) AS t FROM compras")
        tc = cur.fetchone()["t"] or 0
    except Exception:
        tc = 0

    # Últimas ventas
    try:
        cur.execute("SELECT fecha, cliente, total FROM ventas ORDER BY id DESC LIMIT 10")
        ult_ventas = cur.fetchall()
    except Exception:
        ult_ventas = []

    # Ranking productos vendidos (por texto de producto)
    try:
        cur.execute(
            """
            SELECT producto, SUM(total) AS total_importe
            FROM ventas
            GROUP BY producto
            ORDER BY total_importe DESC
            LIMIT 10
            """
        )
        ranking = cur.fetchall()
    except Exception:
        ranking = []

    conn.close()

    margen = tv - tc

    return render_template(
        "reportes_lista.html",
        total_ventas=tv,
        total_compras=tc,
        margen=margen,
        ult_ventas=ult_ventas,
        ranking=ranking,
    )


@reportes_bp.route("/exportar/excel")
def exportar_excel():
    """
    Exporta todas las ventas a un archivo Excel.
    """
    conn = get_db_connection()
    df = pd.read_sql_query("SELECT * FROM ventas", conn)
    conn.close()

    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        df.to_excel(writer, index=False, sheet_name="Ventas")

    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="reporte_ventas.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
