from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection
from datetime import datetime

ctacte_clientes_bp = Blueprint("ctacte_clientes_bp", __name__, url_prefix="/ctacte_clientes")


# LISTA GENERAL
@ctacte_clientes_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT cliente,
               SUM(debe) AS total_debe,
               SUM(haber) AS total_haber,
               SUM(debe - haber) AS saldo
        FROM ctacte_clientes
        GROUP BY cliente
        ORDER BY cliente
    """)
    resumen = cur.fetchall()

    conn.close()
    return render_template("ctacte_clientes_lista.html", resumen=resumen)


# FORM PARA CARGAR MOVIMIENTO
@ctacte_clientes_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        fecha = request.form.get("fecha") or datetime.now().strftime("%Y-%m-%d")
        cliente = request.form.get("cliente", "").strip()
        concepto = request.form.get("concepto", "").strip()
        tipo = request.form.get("tipo", "debe")
        importe = request.form.get("importe", "0").replace(",", ".")

        try:
            importe = float(importe)
        except:
            importe = 0

        debe = importe if tipo == "debe" else 0
        haber = importe if tipo == "haber" else 0

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO ctacte_clientes (fecha, cliente, concepto, debe, haber)
            VALUES (?,?,?,?,?)
        """, (fecha, cliente, concepto, debe, haber))
        conn.commit()
        conn.close()

        flash("Movimiento registrado correctamente", "success")
        return redirect(url_for("ctacte_clientes_bp.lista"))

    return render_template("ctacte_clientes_form.html", mov=None)


# DETALLE POR CLIENTE
@ctacte_clientes_bp.route("/detalle/<cliente>")
def detalle(cliente):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT * FROM ctacte_clientes
        WHERE cliente = ?
        ORDER BY fecha DESC, id DESC
    """, (cliente,))
    movimientos = cur.fetchall()

    cur.execute("""
        SELECT SUM(debe - haber) FROM ctacte_clientes
        WHERE cliente = ?
    """, (cliente,))
    saldo = cur.fetchone()[0] or 0

    conn.close()
    return render_template("ctacte_clientes_detalle.html",
                           cliente=cliente,
                           movimientos=movimientos,
                           saldo=saldo)


# ELIMINAR REGISTRO
@ctacte_clientes_bp.route("/eliminar/<int:mov_id>")
def eliminar(mov_id):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("DELETE FROM ctacte_clientes WHERE id=?", (mov_id,))
    conn.commit()
    conn.close()

    flash("Movimiento eliminado", "info")
    return redirect(request.referrer or url_for("ctacte_clientes_bp.lista"))
