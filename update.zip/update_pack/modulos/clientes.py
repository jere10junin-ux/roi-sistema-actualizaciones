
from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection

clientes_bp = Blueprint("clientes_bp", __name__, url_prefix="/clientes")


@clientes_bp.route("/")
def lista():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM clientes ORDER BY nombre")
    clientes = cur.fetchall()
    conn.close()
    return render_template("clientes_lista.html", clientes=clientes)


@clientes_bp.route("/nuevo", methods=["GET", "POST"])
def nuevo():
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        telefono = request.form.get("telefono", "").strip()
        direccion = request.form.get("direccion", "").strip()
        email = request.form.get("email", "").strip()

        if not nombre:
            flash("El nombre es obligatorio", "danger")
            return redirect(url_for("clientes_bp.nuevo"))

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO clientes (nombre, telefono, direccion, email) VALUES (?,?,?,?)",
            (nombre, telefono, direccion, email),
        )
        conn.commit()
        conn.close()
        flash("Cliente creado correctamente", "success")
        return redirect(url_for("clientes_bp.lista"))

    return render_template("clientes_form.html", cliente=None)


@clientes_bp.route("/editar/<int:cliente_id>", methods=["GET", "POST"])
def editar(cliente_id):
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        telefono = request.form.get("telefono", "").strip()
        direccion = request.form.get("direccion", "").strip()
        email = request.form.get("email", "").strip()

        cur.execute(
            "UPDATE clientes SET nombre=?, telefono=?, direccion=?, email=? WHERE id=?",
            (nombre, telefono, direccion, email, cliente_id),
        )
        conn.commit()
        conn.close()
        flash("Cliente modificado", "success")
        return redirect(url_for("clientes_bp.lista"))

    cur.execute("SELECT * FROM clientes WHERE id=?", (cliente_id,))
    cliente = cur.fetchone()
    conn.close()
    return render_template("clientes_form.html", cliente=cliente)


@clientes_bp.route("/eliminar/<int:cliente_id>")
def eliminar(cliente_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM clientes WHERE id=?", (cliente_id,))
    conn.commit()
    conn.close()
    flash("Cliente eliminado", "info")
    return redirect(url_for("clientes_bp.lista"))
